import random
import _json

def freq_count(nameIn1, keylen, start_offset):
    toDecode1 = bytearray()
    freq = {}
    with open(nameIn1, "rb") as inFile:
        for line in inFile:
            for x in line:
                toDecode1.append(x)
        for i in range(start_offset, len(toDecode1), keylen):
            if freq.get(chr(toDecode1[i] ^ ord(' '))):
                freq[chr(toDecode1[i] ^ ord(' '))] += 1
            else:
                freq[chr(toDecode1[i] ^ ord(' '))] = 1
        print(max(freq, key=freq.get))

    inFile.close()

for l in range(7):
    freq_count("challenge2.txt",7,l)
	
#above piece of code identifies the most frequent character of each offset of the keyword
#below code decrypt the cypher using above given keyword

#password = "Diddledidodah"
password = "Peaches"

def decipher(nameIn, nameOut):
    toDecode = bytearray()
    result = bytearray()
    with open(nameIn, "rb") as inFile, open(nameOut, "wb") as outFile:
        for line in inFile:
            for x in line:
                toDecode.append(x)
                #print(x)
        for i in range(len(toDecode)):
            result.append(toDecode[i] ^ ord(password[i%len(password)]))
            #print(result[i])
        outFile.write(result)

print(decipher("challenge2.txt", "2_op_plain.txt"))